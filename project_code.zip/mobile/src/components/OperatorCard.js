import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking } from 'react-native';

/**
 * Card for displaying a tour operator with contact details.  Uses
 * clickable phone numbers and emails.  The `Linking` API opens the
 * dialer or mail client when the user taps the links.
 */
export default function OperatorCard({ operator }) {
  const handlePhonePress = (phone) => {
    const cleaned = phone.replace(/\s+/g, '');
    Linking.openURL(`tel:${cleaned}`);
  };
  const handleEmailPress = (email) => {
    Linking.openURL(`mailto:${email}`);
  };
  const handleWebsitePress = (url) => {
    Linking.openURL(url);
  };
  return (
    <View style={styles.card}>
      <Text style={styles.name}>{operator.name}</Text>
      <Text style={styles.description}>{operator.description}</Text>
      <View style={styles.contactSection}>
        {operator.phones?.length > 0 && (
          <View style={styles.row}>
            <Text style={styles.label}>Телефон: </Text>
            <View style={styles.valueList}>
              {operator.phones.map((phone, idx) => (
                <TouchableOpacity key={idx} onPress={() => handlePhonePress(phone)}>
                  <Text style={styles.link}>{phone}{idx < operator.phones.length - 1 ? ', ' : ''}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
        {operator.email && (
          <View style={styles.row}>
            <Text style={styles.label}>E‑mail: </Text>
            <TouchableOpacity onPress={() => handleEmailPress(operator.email)}>
              <Text style={styles.link}>{operator.email}</Text>
            </TouchableOpacity>
          </View>
        )}
        <View style={styles.row}>
          <Text style={styles.label}>Адрес: </Text>
          <Text style={styles.text}>{operator.address}</Text>
        </View>
        {operator.website && (
          <View style={styles.row}>
            <Text style={styles.label}>Сайт: </Text>
            <TouchableOpacity onPress={() => handleWebsitePress(operator.website)}>
              <Text style={styles.link}>{operator.website.replace(/^https?:\/\//, '')}</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      <Text style={styles.citation}>{operator.citation}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
    color: '#e74c3c',
  },
  description: {
    fontSize: 14,
    color: '#555',
    marginBottom: 8,
  },
  contactSection: {
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 4,
  },
  label: {
    fontWeight: '600',
    color: '#333',
    marginRight: 4,
  },
  valueList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  link: {
    color: '#e74c3c',
    fontSize: 14,
  },
  text: {
    color: '#333',
    fontSize: 14,
    flexShrink: 1,
  },
  citation: {
    fontSize: 10,
    color: '#999',
    marginTop: 4,
  },
});