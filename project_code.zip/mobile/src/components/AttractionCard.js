import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

/**
 * Card component for displaying an attraction in a list.  Shows a
 * thumbnail image, name, city, and truncated description.  When
 * pressed, the `onPress` callback is invoked by the parent to
 * navigate to the detail screen.
 */
export default function AttractionCard({ item, onPress }) {
  return (
    <TouchableOpacity onPress={() => onPress(item)} style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.image} resizeMode="cover" />
      <View style={styles.content}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.city}>{item.city}</Text>
        <Text style={styles.desc} numberOfLines={3}>
          {item.description}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    marginBottom: 16,
  },
  image: {
    width: '100%',
    height: 160,
  },
  content: {
    padding: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
    color: '#e74c3c',
  },
  city: {
    fontSize: 12,
    color: '#888',
    marginBottom: 4,
  },
  desc: {
    fontSize: 14,
    color: '#555',
  },
});