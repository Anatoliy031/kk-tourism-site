// Данные туроператоров для мобильного приложения.
import data from '../../../website/src/data/operators';

export default data;