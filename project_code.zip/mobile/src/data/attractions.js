// Данные достопримечательностей для мобильного приложения.
// Используется тот же список, что и на веб‑сайте.
import data from '../../../website/src/data/attractions';

export default data;