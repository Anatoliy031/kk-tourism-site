import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import attractions from '../data/attractions';
import AttractionCard from '../components/AttractionCard';

/**
 * Home screen for the mobile app.  Presents a hero section with a
 * search bar and call to action, followed by a horizontal list of
 * featured attractions.  Search terms are passed as params when
 * navigating to the attractions list.
 */
export default function HomeScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const featured = attractions.slice(0, 3);

  const handleSearch = () => {
    navigation.navigate('Attractions', { search: query.trim() });
  };

  return (
    <ScrollView style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://picsum.photos/seed/kuban-hero-mobile/800/600' }}
        style={styles.hero}
      >
        <View style={styles.overlay}>
          <Text style={styles.title}>Откройте для себя Краснодарский край</Text>
          <Text style={styles.subtitle}>
            Путешествуйте по горам, морю и старинным городам
          </Text>
          <View style={styles.searchRow}>
            <TextInput
              style={styles.searchInput}
              placeholder="Поиск по названию"
              value={query}
              onChangeText={setQuery}
            />
            <TouchableOpacity onPress={handleSearch} style={styles.searchButton}>
              <Text style={styles.searchButtonText}>Найти</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('Attractions')}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaButtonText}>Смотреть все</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Популярные места</Text>
        {featured.map((item) => (
          <AttractionCard
            key={item.id}
            item={item}
            onPress={(attraction) =>
              navigation.navigate('AttractionDetail', { id: attraction.id })
            }
          />
        ))}
        <TouchableOpacity
          onPress={() => navigation.navigate('Contacts')}
          style={styles.secondaryCta}
        >
          <Text style={styles.secondaryCtaText}>Контакты туроператоров →</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f6f8fa',
  },
  hero: {
    width: '100%',
    height: 400,
    justifyContent: 'flex-end',
  },
  overlay: {
    backgroundColor: 'rgba(0,0,0,0.45)',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#fff',
    marginBottom: 12,
  },
  searchRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
  },
  searchButton: {
    backgroundColor: '#e74c3c',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
    marginLeft: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  ctaButton: {
    backgroundColor: '#c0392b',
    paddingVertical: 10,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  ctaButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 12,
    color: '#333',
  },
  secondaryCta: {
    marginTop: 8,
    alignItems: 'flex-start',
  },
  secondaryCtaText: {
    color: '#e74c3c',
    fontSize: 14,
    fontWeight: '600',
  },
});