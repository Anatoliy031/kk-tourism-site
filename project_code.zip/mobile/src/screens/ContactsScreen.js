import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import operators from '../data/operators';
import OperatorCard from '../components/OperatorCard';

/**
 * Contacts screen lists tour operators and tourism offices.  Each
 * operator is rendered using the OperatorCard component.  The list
 * scrolls vertically.
 */
export default function ContactsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Контакты туроператоров</Text>
      <FlatList
        data={operators}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <OperatorCard operator={item} />}
        contentContainerStyle={{ paddingBottom: 16 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f6f8fa',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 12,
    color: '#333',
  },
});