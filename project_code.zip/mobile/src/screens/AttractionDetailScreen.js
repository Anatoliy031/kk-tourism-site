import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import attractions from '../data/attractions';

/**
 * Detail screen displays a single attraction.  The attraction id is
 * passed via route parameters.  If the id does not match any record,
 * a fallback message is shown.  The layout includes a hero image
 * followed by text sections for name, location, category and
 * description.
 */
export default function AttractionDetailScreen({ route }) {
  const { id } = route.params;
  const attraction = attractions.find((a) => a.id === id);
  if (!attraction) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.notFoundText}>Достопримечательность не найдена</Text>
      </View>
    );
  }
  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: attraction.image }} style={styles.image} resizeMode="cover" />
      <View style={styles.content}>
        <Text style={styles.name}>{attraction.name}</Text>
        <Text style={styles.location}>
          <Text style={styles.bold}>Город: </Text>
          {attraction.city}
          {'\n'}
          <Text style={styles.bold}>Адрес: </Text>
          {attraction.address}
        </Text>
        <Text style={styles.category}>
          Категория: {attraction.category.charAt(0).toUpperCase() + attraction.category.slice(1)}
        </Text>
        <Text style={styles.description}>{attraction.description}</Text>
        <Text style={styles.citation}>{attraction.citation}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f6f8fa',
  },
  image: {
    width: '100%',
    height: 240,
  },
  content: {
    padding: 16,
    backgroundColor: '#fff',
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    minHeight: 400,
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
    color: '#e74c3c',
  },
  location: {
    fontSize: 14,
    color: '#555',
    marginBottom: 8,
    lineHeight: 20,
  },
  bold: {
    fontWeight: '600',
    color: '#333',
  },
  category: {
    fontSize: 14,
    color: '#888',
    marginBottom: 12,
  },
  description: {
    fontSize: 15,
    color: '#444',
    lineHeight: 22,
    marginBottom: 12,
  },
  citation: {
    fontSize: 10,
    color: '#999',
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notFoundText: {
    fontSize: 18,
    color: '#888',
  },
});