import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import HomeScreen from './src/screens/HomeScreen';
import AttractionsScreen from './src/screens/AttractionsScreen';
import AttractionDetailScreen from './src/screens/AttractionDetailScreen';
import ContactsScreen from './src/screens/ContactsScreen';

const Stack = createNativeStackNavigator();

/**
 * Root component for the mobile application.  Sets up a stack
 * navigator with four screens: home, list of attractions, detail for
 * a single attraction, and contacts.  The status bar uses dark
 * content to suit light backgrounds.  The navigation container
 * handles top-level linking between screens.
 */
export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Курорты Кубани', headerShown: false }}
        />
        <Stack.Screen
          name="Attractions"
          component={AttractionsScreen}
          options={{ title: 'Достопримечательности' }}
        />
        <Stack.Screen
          name="AttractionDetail"
          component={AttractionDetailScreen}
          options={{ title: 'Описание' }}
        />
        <Stack.Screen
          name="Contacts"
          component={ContactsScreen}
          options={{ title: 'Контакты' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}